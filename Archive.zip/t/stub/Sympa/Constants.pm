# -*- indent-tabs-mode: nil; -*-
# vim:ft=perl:et:sw=4
# $Id$

# Test stub for Sympa::Constants;

package Sympa::Constants;

use constant LOCALEDIR => 't/locale';

1;

